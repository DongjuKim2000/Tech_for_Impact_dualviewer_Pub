package com.nightscout.nightviewer

data class BG(var bg: String, var time: String, var arrow: String, var delta: String, var iob: String, var cob: String, var basal: String)

